export const START_GAME = 'START_GAME';
export const GAME_OVER = 'GAME_OVER';
export const ADD_USER = 'ADD_USER';
export const GAME_WON = 'GAME_WON';
export const DEFUSE_CARD = 'DEFUSE_CARD';
export const CAT_CARD = 'CAT_CARD';
export const REMOVE_CARD = 'REMOVE_CARD';
export const FLIPPED_CARD = 'FLIPPED_CARD';
export const SHUFFLE_CARD = 'SHUFFLE_CARD';
export const EXPLODING_KITTEN_CARD = 'EXPLODING_KITTEN_CARD';


